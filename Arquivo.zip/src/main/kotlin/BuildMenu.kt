fun buildMenu() : String{

    val welcome = ("Welcome to the Chess Board Game!")
    val start = ("1-> Start New Game")
    val quit = ("0-> Exit")

    println(welcome)
    println(start)
    println(quit)


    val menuBuilder = welcome + start + quit

    return menuBuilder

}

